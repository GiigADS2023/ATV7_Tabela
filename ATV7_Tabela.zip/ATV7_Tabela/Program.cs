﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // Step 1: Ask to the users what number they would like to see the multiplicacion table
            Console.WriteLine("What do numers you would like to see the multiplicacion table");
            int number = int.Parse(Console.ReadLine());
            int times = 0;

            //Step 2: While
            while (times < 11)
            {

                int result = times * number;
                Console.WriteLine(times + "x" + number + "=" + result);
                times++;    
                
            }

            //Step 3: The end of the program
            Console.WriteLine("End.");
            Console.ReadLine();
        }
    }
}
